using Xunit;
using PingLauncher.Core.Models;

namespace PingLauncher.Tests;

public class SettingsTests
{
    [Fact]
    public void DisplayName_Validation_Works()
    {
        var settings = new UserSettings { LocalDisplayName = "Alex" };
        Assert.Equal("Alex", settings.LocalDisplayName);
    }
}
