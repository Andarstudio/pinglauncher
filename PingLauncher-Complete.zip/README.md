# Ping Launcher

Ping Launcher is a modern, high-performance Minecraft Java Edition launcher built with **C# (.NET 10)** and **Avalonia UI**.

## Features
- First-launch onboarding with display name validation (1–24 characters) & persistent settings.
- Guest mode & Microsoft Account authentication (OAuth 2.0 / MSA / Xbox Live / XSTS token exchange).
- Robust version browser (Vanilla, Fabric, Forge, NeoForge).
- Authenticated Minecraft launch pipeline with argument sanitization (`ProcessStartInfo.ArgumentList`).
- Local mod management (enable/disable JARs).
- Comprehensive unit testing suite.
