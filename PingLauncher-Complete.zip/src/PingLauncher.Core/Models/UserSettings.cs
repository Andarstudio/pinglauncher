namespace PingLauncher.Core.Models;

public class UserSettings
{
    public string LocalDisplayName { get; set; } = string.Empty;
    public bool HasCompletedOnboarding { get; set; }
    public string Theme { get; set; } = "Dark";
    public int MaxRamMb { get; set; } = 4096;
    public string CustomJavaPath { get; set; } = string.Empty;
}
