using CommunityToolkit.Mvvm.ComponentModel;

namespace PingLauncher.App.ViewModels;

public partial class MainViewModel : ObservableObject
{
    [ObservableProperty]
    private string _welcomeMessage = "Welcome to Ping Launcher";
}
